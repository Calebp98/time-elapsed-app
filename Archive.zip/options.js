// Save options to chrome.storage
function saveOptions() {
  const message = document.getElementById("message").value;
  const date = document.getElementById("date").value;

  chrome.storage.sync.set({ message: message, targetDate: date }, function () {
    // Update status to let user know options were saved
    const status = document.getElementById("status");
    status.textContent = "Options saved.";
    setTimeout(function () {
      status.textContent = "";
    }, 2000);
  });
}

// Restore options from chrome.storage
function restoreOptions() {
  chrome.storage.sync.get({ message: "", targetDate: "" }, function (items) {
    document.getElementById("message").value = items.message;
    document.getElementById("date").value = items.targetDate;
  });
}

// Add event listeners
document.addEventListener("DOMContentLoaded", restoreOptions);
document.getElementById("save").addEventListener("click", saveOptions);
